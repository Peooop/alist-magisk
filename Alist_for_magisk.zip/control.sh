#!/system/bin/sh

# 环境变量
MODDIR="$(dirname "$(readlink -f "$0")")"

while true; do # 循环
    if [ -f "./disable" ]; then
        if pgrep -f 'alist' >/dev/null; then
            echo "开关控制$(date "+%Y-%m-%d %H:%M:%S") 进程已存在，正在关闭 ..." >> "$MODDIR/log.log"
            pkill alist # 关闭进程
        fi
    else
        if pgrep -f 'alist' >/dev/null; then
            echo "开关控制$(date "+%Y-%m-%d %H:%M:%S") 进程已存在" >> "$MODDIR/log.log"
        else
            echo "开关控制$(date "+%Y-%m-%d %H:%M:%S") 进程不存在，启动 ..." >> "$MODDIR/log.log"
            $MODDIR/bin/alist admin && $MODDIR/bin/alist server --data "$MODDIR/data" &
        fi
    fi
    sleep 3s # 暂停3秒后再次执行循环
done